#import "TVOSGameBridge.h"
#import <math.h>

static NSString *const kMSEduPrefsBlobKey = @"com.tvos166.metalslug.edu.prefs.v1";

@interface TVOSGameView ()
@property (nonatomic, strong) AVSpeechSynthesizer *ttsSynthesizer;
@end

@implementation TVOSGameView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) { _ttsSynthesizer = [[AVSpeechSynthesizer alloc] init]; }
    return self;
}

- (BOOL)canBecomeFocused { return YES; }

- (void)loadPreferencesFromDefaults {
    if (!self.gameState) return;
    NSData *data = [[NSUserDefaults standardUserDefaults] dataForKey:kMSEduPrefsBlobKey];
    if (data && data.length >= 12) {
        ms_import_prefs_blob(self.gameState, (const uint8_t *)data.bytes, data.length);
    }
}

- (void)savePreferencesToDefaults {
    if (!self.gameState) return;
    uint8_t buf[16] = {0};
    size_t n = ms_export_prefs_blob(self.gameState, buf, sizeof(buf));
    if (n > 0) {
        NSData *data = [NSData dataWithBytes:buf length:n];
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:kMSEduPrefsBlobKey];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

- (void)applyResolutionSettings {
    ms_game_state_t *st = self.gameState;
    if (!st) return;
    CGFloat desiredScale = (CGFloat)st->effective_render_scale;
    if (st->switches.remaster_tier >= 2 && desiredScale < 1.5 && st->switches.hi_res_upscale) desiredScale = 1.5;
    if (desiredScale > 2.0) desiredScale = 2.0;
    if (desiredScale < 1.0) desiredScale = 1.0;
    self.contentScaleFactor = desiredScale;
    [self setNeedsDisplay];
}

- (void)cycleResolutionScale {
    ms_game_state_t *st = self.gameState;
    if (!st) return;
    int cur = st->switches.render_scale_percent;
    int next = (cur < 150) ? 150 : ((cur < 200) ? 200 : 100);
    st->switches.hi_res_upscale = (next > 100);
    st->switches.render_scale_percent = next;
    ms_recalc_resolution(st);
    [self applyResolutionSettings];
    [self savePreferencesToDefaults];
}

- (void)toggleHangulEduMode {
    ms_game_state_t *st = self.gameState;
    if (!st) return;
    st->switches.hangul_edu_mode = !st->switches.hangul_edu_mode;
    [self savePreferencesToDefaults];
}

- (void)speakCurrentQuizPrompt {
    ms_game_state_t *st = self.gameState;
    if (!st || !st->switches.sound_enabled || !st->switches.hangul_edu_mode) return;
    const ms_hangul_quiz_t *q = ms_hangul_get_quiz(st->quiz.quiz_index);
    if (!q || !q->tts_utf8) return;
    if (self.ttsSynthesizer.isSpeaking) {
        [self.ttsSynthesizer stopSpeakingAtBoundary:AVSpeechBoundaryImmediate];
    }
    AVSpeechUtterance *utt = [AVSpeechUtterance speechUtteranceWithString:[NSString stringWithUTF8String:q->tts_utf8]];
    utt.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"ko-KR"];
    utt.rate = 0.45f;
    [self.ttsSynthesizer speakUtterance:utt];
}

- (uint32_t)pollCombinedInputMask {
    uint32_t mask = self.activeInputMask;
    for (GCController *ctrl in [GCController controllers]) {
        if (ctrl.extendedGamepad) {
            GCExtendedGamepad *gp = ctrl.extendedGamepad;
            if (gp.dpad.left.isPressed || gp.leftThumbstick.xAxis.value < -0.35f) mask |= MS_INPUT_LEFT;
            if (gp.dpad.right.isPressed || gp.leftThumbstick.xAxis.value > 0.35f) mask |= MS_INPUT_RIGHT;
            if (gp.dpad.up.isPressed || gp.rightShoulder.isPressed)               mask |= MS_INPUT_AIM_UP;
            if (gp.dpad.down.isPressed || gp.leftShoulder.isPressed)              mask |= MS_INPUT_AIM_DOWN;
            if (gp.buttonA.isPressed) mask |= MS_INPUT_JUMP;
            if (gp.buttonX.isPressed || gp.rightTrigger.isPressed) mask |= MS_INPUT_FIRE;
            if (gp.buttonB.isPressed) mask |= MS_INPUT_GRENADE;
            if (gp.buttonY.isPressed) mask |= MS_INPUT_SLUG_TOGGLE;
            if (gp.leftTrigger.isPressed) [self speakCurrentQuizPrompt];
        }
    }
    return mask;
}

- (void)pressesBegan:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
    for (UIPress *p in presses) {
        UIKey *key = p.key;
        if (key) {
            NSString *ch = key.charactersIgnoringModifiers.lowercaseString;
            if ([ch isEqualToString:@"a"] || key.keyCode == UIKeyboardHIDUsageKeyboardLeftArrow) self.activeInputMask |= MS_INPUT_LEFT;
            else if ([ch isEqualToString:@"d"] || key.keyCode == UIKeyboardHIDUsageKeyboardRightArrow) self.activeInputMask |= MS_INPUT_RIGHT;
            else if (key.keyCode == UIKeyboardHIDUsageKeyboardUpArrow || [ch isEqualToString:@"q"]) self.activeInputMask |= MS_INPUT_AIM_UP;
            else if (key.keyCode == UIKeyboardHIDUsageKeyboardDownArrow || [ch isEqualToString:@"c"]) self.activeInputMask |= MS_INPUT_AIM_DOWN;
            else if ([ch isEqualToString:@"w"] || key.keyCode == UIKeyboardHIDUsageKeyboardSpacebar) self.activeInputMask |= MS_INPUT_JUMP;
            else if ([ch isEqualToString:@"j"] || [ch isEqualToString:@"z"]) self.activeInputMask |= MS_INPUT_FIRE;
            else if ([ch isEqualToString:@"k"] || [ch isEqualToString:@"x"]) self.activeInputMask |= MS_INPUT_GRENADE;
            else if ([ch isEqualToString:@"e"] || key.keyCode == UIKeyboardHIDUsageKeyboardReturnOrEnter) self.activeInputMask |= MS_INPUT_SLUG_TOGGLE;
            else if ([ch isEqualToString:@"r"]) [self cycleResolutionScale];
            else if ([ch isEqualToString:@"t"]) [self speakCurrentQuizPrompt];
            else if ([ch isEqualToString:@"h"]) [self toggleHangulEduMode];
            else if (key.keyCode == UIKeyboardHIDUsageKeyboardEscape || [ch isEqualToString:@"p"]) self.activeInputMask |= MS_INPUT_PAUSE;
        } else if (p.type == UIPressTypeSelect) self.activeInputMask |= MS_INPUT_FIRE;
        else if (p.type == UIPressTypePlayPause) self.activeInputMask |= MS_INPUT_PAUSE;
    }
    [super pressesBegan:presses withEvent:event];
}

- (void)pressesEnded:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
    for (UIPress *p in presses) {
        UIKey *key = p.key;
        if (key) {
            NSString *ch = key.charactersIgnoringModifiers.lowercaseString;
            if ([ch isEqualToString:@"a"] || key.keyCode == UIKeyboardHIDUsageKeyboardLeftArrow) self.activeInputMask &= ~MS_INPUT_LEFT;
            else if ([ch isEqualToString:@"d"] || key.keyCode == UIKeyboardHIDUsageKeyboardRightArrow) self.activeInputMask &= ~MS_INPUT_RIGHT;
            else if (key.keyCode == UIKeyboardHIDUsageKeyboardUpArrow || [ch isEqualToString:@"q"]) self.activeInputMask &= ~MS_INPUT_AIM_UP;
            else if (key.keyCode == UIKeyboardHIDUsageKeyboardDownArrow || [ch isEqualToString:@"c"]) self.activeInputMask &= ~MS_INPUT_AIM_DOWN;
            else if ([ch isEqualToString:@"w"] || key.keyCode == UIKeyboardHIDUsageKeyboardSpacebar) self.activeInputMask &= ~MS_INPUT_JUMP;
            else if ([ch isEqualToString:@"j"] || [ch isEqualToString:@"z"]) self.activeInputMask &= ~MS_INPUT_FIRE;
            else if ([ch isEqualToString:@"k"] || [ch isEqualToString:@"x"]) self.activeInputMask &= ~MS_INPUT_GRENADE;
            else if ([ch isEqualToString:@"e"] || key.keyCode == UIKeyboardHIDUsageKeyboardReturnOrEnter) self.activeInputMask &= ~MS_INPUT_SLUG_TOGGLE;
            else if (key.keyCode == UIKeyboardHIDUsageKeyboardEscape || [ch isEqualToString:@"p"]) self.activeInputMask &= ~MS_INPUT_PAUSE;
        } else if (p.type == UIPressTypeSelect) self.activeInputMask &= ~MS_INPUT_FIRE;
        else if (p.type == UIPressTypePlayPause) self.activeInputMask &= ~MS_INPUT_PAUSE;
    }
    [super pressesEnded:presses withEvent:event];
}

- (void)drawSubtleAutoReticle:(CGContextRef)ctx state:(ms_game_state_t *)st sx:(float)sx sy:(float)sy {
    ms_aim_target_t aim;
    ms_find_aim_target(st, &aim);
    CGFloat tx = (aim.world_x - st->camera_x) * sx;
    CGFloat ty = aim.world_y * sy;
    CGFloat s  = MAX(1.0f, sx);

    CGContextSaveGState(ctx);
    CGContextSetLineCap(ctx, kCGLineCapRound);

    CGFloat r = (aim.locked ? 15.0 : 12.0) * s;
    CGFloat gap = 6.0 * s;
    CGFloat tick = 6.0 * s;
    CGRect circle = CGRectMake(tx - r, ty - r, r * 2.0, r * 2.0);

    CGContextSetStrokeColorWithColor(ctx, [[UIColor blackColor] colorWithAlphaComponent:(aim.locked ? 0.72 : 0.45)].CGColor);
    CGContextSetLineWidth(ctx, 3.8 * s);
    CGContextStrokeEllipseInRect(ctx, circle);
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, tx - r - tick, ty); CGContextAddLineToPoint(ctx, tx - gap, ty);
    CGContextMoveToPoint(ctx, tx + gap, ty);      CGContextAddLineToPoint(ctx, tx + r + tick, ty);
    CGContextMoveToPoint(ctx, tx, ty - r - tick); CGContextAddLineToPoint(ctx, tx, ty - gap);
    CGContextMoveToPoint(ctx, tx, ty + gap);      CGContextAddLineToPoint(ctx, tx, ty + r + tick);
    CGContextStrokePath(ctx);

    UIColor *innerColor = aim.locked
        ? [UIColor colorWithRed:1.0 green:0.28 blue:0.22 alpha:0.95]
        : [UIColor colorWithWhite:1.0 alpha:0.55];
    CGContextSetStrokeColorWithColor(ctx, innerColor.CGColor);
    CGContextSetLineWidth(ctx, 1.9 * s);
    CGContextStrokeEllipseInRect(ctx, circle);
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, tx - r - tick, ty); CGContextAddLineToPoint(ctx, tx - gap, ty);
    CGContextMoveToPoint(ctx, tx + gap, ty);      CGContextAddLineToPoint(ctx, tx + r + tick, ty);
    CGContextMoveToPoint(ctx, tx, ty - r - tick); CGContextAddLineToPoint(ctx, tx, ty - gap);
    CGContextMoveToPoint(ctx, tx, ty + gap);      CGContextAddLineToPoint(ctx, tx, ty + r + tick);
    CGContextStrokePath(ctx);

    float deg = ms_get_aim_angle_deg(st->player.aim_angle_index);
    NSString *angText = [NSString stringWithFormat:@" %d° ", (int)deg];
    UIFont *angFont = [UIFont monospacedSystemFontOfSize:18.0 * s weight:UIFontWeightBold];
    NSDictionary *angAttrs = @{
        NSFontAttributeName: angFont,
        NSForegroundColorAttributeName: [UIColor colorWithRed:1.0 green:0.94 blue:0.35 alpha:1.0],
        NSBackgroundColorAttributeName: [[UIColor blackColor] colorWithAlphaComponent:0.68]
    };
    [angText drawAtPoint:CGPointMake((st->player.x - st->camera_x) * sx, (st->player.y - st->player.h - 28.0f) * sy)
          withAttributes:angAttrs];
    CGContextRestoreGState(ctx);
}

- (void)drawCrispBullets:(CGContextRef)ctx state:(ms_game_state_t *)st sx:(float)sx sy:(float)sy {
    CGFloat s = MAX(1.0f, sx);
    CGContextSaveGState(ctx);
    CGContextSetLineCap(ctx, kCGLineCapRound);

    for (int i = 0; i < MS_MAX_BULLETS; ++i) {
        ms_bullet_t *b = &st->bullets[i];
        if (!b->active) continue;
        CGFloat bx = (b->x - st->camera_x) * sx;
        CGFloat by = b->y * sy;

        if (b->is_grenade) {
            CGRect gr = CGRectMake(bx - 8.0 * s, by - 8.0 * s, 16.0 * s, 16.0 * s);
            [[UIColor blackColor] setFill];
            CGContextFillEllipseInRect(ctx, CGRectInset(gr, -2.0 * s, -2.0 * s));
            [[UIColor colorWithRed:0.35 green:0.80 blue:0.30 alpha:1.0] setFill];
            CGContextFillEllipseInRect(ctx, gr);
            continue;
        }

        if (b->from_player) {
            float spd = sqrtf(b->vx * b->vx + b->vy * b->vy);
            float ux = (spd > 1.0f) ? (b->vx / spd) : 1.0f;
            float uy = (spd > 1.0f) ? (b->vy / spd) : 0.0f;
            CGFloat tx = bx - ux * 26.0 * s;
            CGFloat ty = by - uy * 26.0 * s;

            CGContextSetStrokeColorWithColor(ctx, [[UIColor blackColor] colorWithAlphaComponent:0.85].CGColor);
            CGContextSetLineWidth(ctx, 9.0 * s);
            CGContextBeginPath(ctx); CGContextMoveToPoint(ctx, tx, ty); CGContextAddLineToPoint(ctx, bx, by); CGContextStrokePath(ctx);

            CGContextSetStrokeColorWithColor(ctx, [UIColor colorWithRed:1.0 green:0.82 blue:0.12 alpha:1.0].CGColor);
            CGContextSetLineWidth(ctx, 5.5 * s);
            CGContextBeginPath(ctx); CGContextMoveToPoint(ctx, tx, ty); CGContextAddLineToPoint(ctx, bx, by); CGContextStrokePath(ctx);

            CGContextSetStrokeColorWithColor(ctx, [UIColor colorWithRed:1.0 green:1.0 blue:0.85 alpha:1.0].CGColor);
            CGContextSetLineWidth(ctx, 2.5 * s);
            CGContextBeginPath(ctx); CGContextMoveToPoint(ctx, bx - ux * 10.0 * s, by - uy * 10.0 * s); CGContextAddLineToPoint(ctx, bx, by); CGContextStrokePath(ctx);
        } else {
            CGRect er = CGRectMake(bx - 6.5 * s, by - 6.5 * s, 13.0 * s, 13.0 * s);
            [[UIColor blackColor] setFill];
            CGContextFillEllipseInRect(ctx, CGRectInset(er, -2.0 * s, -2.0 * s));
            [[UIColor colorWithRed:1.0 green:0.35 blue:0.15 alpha:1.0] setFill];
            CGContextFillEllipseInRect(ctx, er);
        }
    }
    CGContextRestoreGState(ctx);
}

- (void)drawHighResHUD:(ms_game_state_t *)st viewBounds:(CGRect)rect {
    CGFloat baseAspectScale = MIN(rect.size.width / 1920.0, rect.size.height / 1080.0);
    CGFloat uiScale = ((CGFloat)st->switches.ui_scale_percent / 100.0) * MAX(1.0, baseAspectScale);
    UIFont *hudFont = [UIFont monospacedSystemFontOfSize:24.0 * uiScale weight:UIFontWeightBold];
    NSString *hudText = [NSString stringWithFormat:@"HP:%d  SLUG:%d  SCORE:%d  BEST:%d  RES:%dx%d",
                         st->player.hp, st->player.slug_hp, st->score, st->best_score,
                         st->target_width, st->target_height];
    NSDictionary *attrs = @{
        NSFontAttributeName: hudFont,
        NSForegroundColorAttributeName: [UIColor whiteColor],
        NSBackgroundColorAttributeName: [[UIColor blackColor] colorWithAlphaComponent:0.80]
    };
    [hudText drawAtPoint:CGPointMake(28.0 * uiScale, 24.0 * uiScale) withAttributes:attrs];

    if (st->switches.hangul_edu_mode && st->quiz.active) {
        const ms_hangul_quiz_t *q = ms_hangul_get_quiz(st->quiz.quiz_index);
        if (q && q->prompt_utf8) {
            NSString *qStr = [NSString stringWithFormat:@"  %@  [T:듣기]  ",
                              [NSString stringWithUTF8String:q->prompt_utf8]];
            UIFont *qFont = [UIFont systemFontOfSize:28.0 * uiScale weight:UIFontWeightHeavy];
            NSDictionary *qAttrs = @{
                NSFontAttributeName: qFont,
                NSForegroundColorAttributeName: [UIColor colorWithRed:1.0 green:0.96 blue:0.25 alpha:1.0],
                NSBackgroundColorAttributeName: [[UIColor blackColor] colorWithAlphaComponent:0.86]
            };
            CGSize sz = [qStr sizeWithAttributes:qAttrs];
            [qStr drawAtPoint:CGPointMake(rect.size.width - sz.width - 28.0 * uiScale, 22.0 * uiScale)
               withAttributes:qAttrs];
        }
    }
}

- (void)drawRect:(CGRect)rect {
    ms_game_state_t *st = self.gameState;
    if (!st || !st->initialized) return;
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    if (!ctx) return;

    float sx = rect.size.width / 1920.0f;
    float sy = rect.size.height / 1080.0f;

    /* 다층 사막 노을 배경 (그래픽 향상) */
    [[UIColor colorWithRed:0.34 green:0.42 blue:0.52 alpha:1.0] setFill];
    CGContextFillRect(ctx, CGRectMake(0, 0, rect.size.width, 280.0f * sy));
    [[UIColor colorWithRed:0.78 green:0.58 blue:0.38 alpha:1.0] setFill];
    CGContextFillRect(ctx, CGRectMake(0, 280.0f * sy, rect.size.width, (MS_GROUND_Y - 280.0f) * sy));
    [[UIColor colorWithRed:0.65 green:0.48 blue:0.28 alpha:1.0] setFill];
    CGContextFillRect(ctx, CGRectMake(0, MS_GROUND_Y * sy, rect.size.width, rect.size.height - (MS_GROUND_Y * sy)));

    float px = (st->player.x - st->camera_x) * sx;
    float py = (st->player.y - st->player.h) * sy;
    UIColor *pColor = st->player.in_slug
        ? [UIColor colorWithRed:0.95 green:0.75 blue:0.15 alpha:1.0]
        : [UIColor colorWithRed:0.22 green:0.68 blue:0.34 alpha:1.0];
    [pColor setFill];
    CGContextFillRect(ctx, CGRectMake(px, py, st->player.w * sx, st->player.h * sy));

    const ms_hangul_quiz_t *curQuiz = st->quiz.active ? ms_hangul_get_quiz(st->quiz.quiz_index) : NULL;
    for (int i = 0; i < MS_MAX_ENEMIES; ++i) {
        ms_enemy_t *en = &st->enemies[i];
        if (!en->active) continue;
        float ew = (en->kind == MS_ENEMY_TANK || en->kind == MS_ENEMY_HELI) ? 72.0f : 48.0f;
        float eh = 56.0f;
        float ex = (en->x - st->camera_x) * sx;
        float ey = (en->y - eh) * sy;

        if (en->kind == MS_ENEMY_TOWER_GUARD) {
            [[UIColor colorWithRed:0.42 green:0.30 blue:0.18 alpha:1.0] setFill];
            CGContextFillRect(ctx, CGRectMake(ex + 6.0f * sx, en->y * sy, (ew - 12.0f) * sx, (MS_GROUND_Y - en->y) * sy));
        } else if (en->kind == MS_ENEMY_BUNKER_GUARD) {
            [[UIColor colorWithRed:0.48 green:0.43 blue:0.32 alpha:1.0] setFill];
            CGContextFillRect(ctx, CGRectMake(ex - 16.0f * sx, en->y * sy, (ew + 32.0f) * sx, (MS_GROUND_Y - en->y) * sy));
        } else if (en->kind == MS_ENEMY_PARATROOPER) {
            [[UIColor colorWithRed:0.55 green:0.65 blue:0.45 alpha:1.0] setFill];
            CGContextFillEllipseInRect(ctx, CGRectMake(ex - 14.0f * sx, ey - 34.0f * sy, (ew + 28.0f) * sx, 30.0f * sy));
        }

        UIColor *eColor = (en->stun_frames > 0)
            ? [UIColor colorWithRed:0.35 green:0.75 blue:0.95 alpha:1.0]
            : [UIColor colorWithRed:0.84 green:0.22 blue:0.20 alpha:1.0];
        [eColor setFill];
        CGContextFillRect(ctx, CGRectMake(ex, ey, ew * sx, eh * sy));

        if (en->is_quiz_unit && curQuiz && en->choice_slot < MS_QUIZ_CHOICE_COUNT) {
            const char *chUtf8 = curQuiz->choices_utf8[en->choice_slot];
            if (chUtf8) {
                NSString *badgeStr = [NSString stringWithUTF8String:chUtf8];
                CGFloat br = 36.0 * MAX(1.0f, sx);
                CGFloat bx = ex + (ew * sx) * 0.5f;
                CGFloat by = ey - br - 16.0 * sy;
                CGRect circle = CGRectMake(bx - br, by - br, br * 2.0, br * 2.0);
                [[[UIColor blackColor] colorWithAlphaComponent:0.86] setFill];
                CGContextFillEllipseInRect(ctx, circle);
                [[UIColor whiteColor] setStroke];
                CGContextSetLineWidth(ctx, 3.0 * MAX(1.0f, sx));
                CGContextStrokeEllipseInRect(ctx, circle);

                UIFont *bFont = [UIFont systemFontOfSize:34.0 * MAX(1.0f, sx) weight:UIFontWeightHeavy];
                NSDictionary *bAttrs = @{ NSFontAttributeName: bFont, NSForegroundColorAttributeName: [UIColor whiteColor] };
                CGSize tsz = [badgeStr sizeWithAttributes:bAttrs];
                [badgeStr drawAtPoint:CGPointMake(bx - tsz.width * 0.5, by - tsz.height * 0.5) withAttributes:bAttrs];
            }
        }
    }

    for (int i = 0; i < MS_MAX_PARTICLES; ++i) {
        ms_particle_t *pt = &st->particles[i];
        if (!pt->active) continue;
        [[UIColor colorWithRed:1.0 green:0.75 blue:0.2 alpha:1.0] setFill];
        CGContextFillRect(ctx, CGRectMake((pt->x - st->camera_x) * sx, pt->y * sy, 7.0f * sx, 7.0f * sy));
    }

    [self drawCrispBullets:ctx state:st sx:sx sy:sy];
    [self drawSubtleAutoReticle:ctx state:st sx:sx sy:sy];
    [self drawHighResHUD:st viewBounds:rect];
}

@end

#include "ms_game.h"
#include <stdio.h>
#include <string.h>

int main(void) {
    ms_game_state_t game;
    ms_switches_t sw = {
        .safe_mode_fallback   = false,
        .high_contrast_hud    = true,
        .sound_enabled        = true,
        .ui_scale_percent     = 150,
        .hi_res_upscale       = true,
        .render_scale_percent = 200,
        .remaster_tier        = 2,
        .hangul_edu_mode      = true,
        .edu_level            = 1
    };

    ms_game_init(&game, 1, 0, sw);

    for (int f = 0; f < 100; ++f) {
        ms_game_step(&game, MS_INPUT_NONE, 1.0f / 60.0f);
    }

    ms_aim_target_t aim45;
    ms_find_aim_target(&game, &aim45);

    for (int f = 0; f < 140; ++f) {
        ms_game_step(&game, MS_INPUT_FIRE, 1.0f / 60.0f);
    }

    int stunned_count = 0;
    for (int i = 0; i < MS_MAX_ENEMIES; ++i) {
        if (game.enemies[i].active && game.enemies[i].stun_frames > 0) stunned_count++;
    }

    uint8_t blob[16] = {0};
    size_t blob_len = ms_export_prefs_blob(&game, blob, sizeof(blob));
    ms_game_state_t restored;
    memset(&restored, 0, sizeof(restored));
    bool ok = ms_import_prefs_blob(&restored, blob, blob_len);

    printf("[EDU] aim45_locked=%d aim45_dist=%.1f score=%d correct_defeated=%d stunned=%d blob_len=%zu restore_ok=%d edu=%d diag=\"%s\"\n",
           aim45.locked ? 1 : 0, aim45.distance, game.score,
           game.quiz.correct_defeated ? 1 : 0, stunned_count,
           blob_len, ok ? 1 : 0, restored.switches.hangul_edu_mode ? 1 : 0, game.last_diag_note);

    ms_release_stage_assets(&game);
    return (ok && aim45.locked && game.quiz.correct_defeated) ? 0 : 1;
}

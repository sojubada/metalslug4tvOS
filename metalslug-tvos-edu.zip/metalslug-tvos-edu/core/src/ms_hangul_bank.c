#include "ms_hangul_bank.h"

static const ms_hangul_quiz_t kHangulBank[] = {
    {
        .id = 1, .level = 1,
        .prompt_utf8 = "하늘에서 내리는 하얀 ___",
        .tts_utf8 = "하늘에서 내리는 하얀 무엇일까요? 눈.",
        .choices_utf8 = { "논", "문", "눈", "물", "불" },
        .correct_index = 2
    },
    {
        .id = 2, .level = 1,
        .prompt_utf8 = "밤하늘에 반짝이는 ___",
        .tts_utf8 = "밤하늘에 반짝이는 무엇일까요? 별.",
        .choices_utf8 = { "벌", "별", "발", "불", "벽" },
        .correct_index = 1
    },
    {
        .id = 3, .level = 1,
        .prompt_utf8 = "시원한 파도가 치는 ___",
        .tts_utf8 = "시원한 파도가 치는 곳은 어디일까요? 바다.",
        .choices_utf8 = { "바다", "파다", "바라", "마다", "버다" },
        .correct_index = 0
    },
    {
        .id = 4, .level = 2,
        .prompt_utf8 = "꼬끼오 아침을 알리는 ___",
        .tts_utf8 = "꼬끼오 아침을 알리는 동물은 무엇일까요? 닭.",
        .choices_utf8 = { "달", "닥", "닦", "닭", "담" },
        .correct_index = 3
    },
    {
        .id = 5, .level = 2,
        .prompt_utf8 = "봄에 예쁘게 피어나는 ___",
        .tts_utf8 = "봄에 예쁘게 피어나는 것은 무엇일까요? 꽃.",
        .choices_utf8 = { "곳", "곶", "끝", "꿈", "꽃" },
        .correct_index = 4
    },
    {
        .id = 6, .level = 2,
        .prompt_utf8 = "집을 지키는 귀여운 ___",
        .tts_utf8 = "집을 지키는 귀여운 동물은 무엇일까요? 개.",
        .choices_utf8 = { "게", "개", "계", "깨", "배" },
        .correct_index = 1
    },
    {
        .id = 7, .level = 1,
        .prompt_utf8 = "연필로 공책에 글씨를 ___",
        .tts_utf8 = "연필로 공책에 글씨를 무엇할까요? 써요.",
        .choices_utf8 = { "서요", "셔요", "써요", "싸요", "쏘요" },
        .correct_index = 2
    },
    {
        .id = 8, .level = 2,
        .prompt_utf8 = "해가 높이 뜬 밝은 ___",
        .tts_utf8 = "해가 높이 뜬 밝은 시간은 언제일까요? 낮.",
        .choices_utf8 = { "낫", "날", "남", "낯", "낮" },
        .correct_index = 4
    }
};

int ms_hangul_quiz_count(void) {
    return (int)(sizeof(kHangulBank) / sizeof(kHangulBank[0]));
}

const ms_hangul_quiz_t *ms_hangul_get_quiz(uint16_t index) {
    int cnt = ms_hangul_quiz_count();
    if (cnt <= 0) return 0;
    return &kHangulBank[index % (uint16_t)cnt];
}

#ifndef MS_HANGUL_BANK_H
#define MS_HANGUL_BANK_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MS_QUIZ_CHOICE_COUNT 5

typedef struct {
    uint16_t    id;
    uint8_t     level;
    const char *prompt_utf8;
    const char *tts_utf8;
    const char *choices_utf8[MS_QUIZ_CHOICE_COUNT];
    uint8_t     correct_index;
} ms_hangul_quiz_t;

int                     ms_hangul_quiz_count(void);
const ms_hangul_quiz_t *ms_hangul_get_quiz(uint16_t index);

#ifdef __cplusplus
}
#endif

#endif /* MS_HANGUL_BANK_H */
